// app/signup/page.tsx
"use client";

export default function GatheringsPage() {
  return (
    <div className="px-4 py-6">
   
    </div>
  )
}



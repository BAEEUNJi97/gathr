// src/app/gatherings/detail/[id]/page.tsx
import { notFound } from 'next/navigation';
import GatheringDetailPage from '@/components/gatherings/detail/GatheringDetailPage';
import { getGatheringDetail } from '@/services/gatheringService';
import { GatheringDetail } from '@/types/gathering';

interface PageProps {
  // params를 Promise<{ id: string }> 로 받습니다
  params: Promise<{ teamId: string; id: string }>;
}

export default async function Page({ params }: PageProps) {
  // 1) params를 await 해서 id(teamId) 를 꺼냅니다
  const { teamId, id } = await params;

  let detail: GatheringDetail;
  try {
    detail = await getGatheringDetail(teamId, Number(id));
  } catch (err: any) {
    if (err.response?.status === 404) {
      return notFound();
    }
    throw err;
  }

  // 2) 정상 조회된 데이터를 아래 컴포넌트에 넘깁니다
  return <GatheringDetailPage gathering={detail} />;
}

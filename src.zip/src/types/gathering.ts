/**
 * 가능한 서비스 종류 (백엔드 스펙과 일치)
 */
export enum GatheringType {
  DALLAEMFIT = "DALLAEMFIT",
  OFFICE_STRETCHING = "OFFICE_STRETCHING",
  MINDFULNESS = "MINDFULNESS",
  WORKATION = "WORKATION",
}

export const GATHERING_LABEL_MAP: Record<GatheringType, string> = {
  DALLAEMFIT: "전체",
  OFFICE_STRETCHING: "오피스 스트레칭",
  MINDFULNESS: "마인드풀니스",
  WORKATION: "전체",
};

export const MAIN_TAB_TYPE_MAP = {
  DALLEM: [
    GatheringType.DALLAEMFIT,
    GatheringType.OFFICE_STRETCHING,
    GatheringType.MINDFULNESS,
  ],
  WORKATION: [GatheringType.WORKATION],
} as const;

export type MainTab = keyof typeof MAIN_TAB_TYPE_MAP;

export type SubTab = GatheringType;

/**
 * 상태 관리용: 모임 목록 필터링 조건
 */
export interface GatheringFilters {
  mainTab: MainTab;                          // 메인탭: 달램, 워케이션
  subTab: SubTab | "";                       // 서브탭: 달램핏 등 (비었으면 전체)
  location: "" | "건대입구" | "을지로3가" | "신림" | "홍대입구";
  date: string;                              // 'YYYY-MM-DD' 등
  sortBy: "dateTime" | "registrationEnd" | "participantCount";
  sortOrder: "asc" | "desc";
}

/**
 * API 요청용: 모임 리스트 API 파라미터
 * (서버에 넘길 때는 mainTab, subTab 없이 실제 필요한 필드만!)
 */
export interface GatheringListApiParams {
  type: GatheringType;                                   // 서버가 요구하는 타입만!
  location?: "" | "건대입구" | "을지로3가" | "신림" | "홍대입구";
  date?: string;
  sortBy?: "dateTime" | "registrationEnd" | "participantCount";
  sortOrder?: "asc" | "desc";
}

/**
 * 모임 생성 폼 데이터
 */
export interface CreateGatheringForm {
  name: string;
  location: string;
  type: GatheringType;
  dateTime: string;
  registrationEnd: string;
  capacity: number;
  image: File | null;
}

/**
 * 서버에서 내려주는 모임 객체
 */
export interface Gathering {
  id: number;
  teamId?: string;
  name: string;
  location: string;
  image: string;
  type: GatheringType;
  /** 선택적 서브 타입 (예: OFFICE_STRETCHING 내 세부 분류) */
  subType?: string;
  dateTime: string;           // 모임 시작 날짜와 시간
  registrationEnd: string;    // 모집 마감 시간
  capacity: number;
  participantCount: number;
}

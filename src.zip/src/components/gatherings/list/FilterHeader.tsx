import { useFilters } from '@/contexts/FilterContext';
import { MAIN_TAB_TYPE_MAP, GatheringType, MainTab, GatheringFilters, GATHERING_LABEL_MAP } from '@/types/gathering';
import { MouseEvent } from 'react';

interface FilterHeaderProps {
  openModal: () => void;
  isLoggedIn?: boolean;
}

export default function FilterHeader({ openModal, isLoggedIn = true }: FilterHeaderProps) {
  const { filters, setFilters } = useFilters();

  // 메인탭 클릭
  const handleMainTab = (tab: MainTab) => {
    setFilters((prev) => ({
      ...prev,
      mainTab: tab,
      subTab: '', // 메인탭 바뀌면 서브탭 리셋!
    }));
  };

  // 현재 메인탭에 해당하는 서브탭(타입) 목록
  const subTabTypes: GatheringType[] = [...MAIN_TAB_TYPE_MAP[filters.mainTab]];

  // 서브탭 클릭
  const handleSubTab = (type: GatheringType) => {
    setFilters((prev) => ({
      ...prev,
      subTab: prev.subTab === type ? '' : type, // 동일한 서브탭 누르면 전체보기
    }));
  };

  // 위치 필터
    const handleLocation = (e: React.ChangeEvent<HTMLSelectElement>) =>
    setFilters(prev => ({
      ...prev,
      location: e.target.value as GatheringFilters['location'],
    }));

  // 날짜 필터
const handleDate = (e: React.ChangeEvent<HTMLInputElement>) =>
    setFilters(prev => ({
      ...prev,
      date: e.target.value,
    }));


  return (
    <div className="mb-6">
      {/* 메인탭 */}
      <div className="flex gap-2 mb-2">
        <button
          type="button"
          className={`px-4 py-2 rounded-lg font-bold transition
            ${filters.mainTab === 'DALLEM' ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-700'}
          `}
          onClick={() => handleMainTab('DALLEM')}
        >
          달램
        </button>
        <button
          type="button"
          className={`px-4 py-2 rounded-lg font-bold transition
            ${filters.mainTab === 'WORKATION' ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-700'}
          `}
          onClick={() => handleMainTab('WORKATION')}
        >
          워케이션
        </button>
        {/* 모임만들기 버튼은 우측 배치 예시 */}
        <div className="flex-1 text-right">
          {isLoggedIn && (
            <button
              type="button"
              className="ml-4 bg-orange-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-orange-700 transition"
              onClick={openModal}
            >
               모임 만들기
            </button>
          )}
        </div>
      </div>

      {/* 서브탭 */}
      <div className="flex gap-2 mb-2">
        {subTabTypes.map((type) => (
          <button
            key={type}
            type="button"
            className={`px-3 py-1 rounded transition font-semibold
              ${filters.subTab === type ? 'bg-orange-400 text-white' : 'bg-gray-200 text-gray-700'}
            `}
            onClick={() => handleSubTab(type)}
          >
            {GATHERING_LABEL_MAP[type]}
          </button>
        ))}
      </div>

      {/* 위치/날짜 필터 */}
      <div className="flex gap-4 items-center">
        <select value={filters.location} onChange={handleLocation} className="border rounded px-2 py-1">
          <option value="">전체 지역</option>
          <option value="건대입구">건대입구</option>
          <option value="을지로3가">을지로3가</option>
          <option value="신림">신림</option>
          <option value="홍대입구">홍대입구</option>
        </select>
        <input
          type="date"
          value={filters.date}
          onChange={handleDate}
          className="border rounded px-2 py-1"
        />
      </div>
    </div>
  );
}

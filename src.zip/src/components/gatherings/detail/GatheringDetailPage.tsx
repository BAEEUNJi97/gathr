// components/gatherings/detail/GatheringDetailPage.tsx
'use client';

import React from 'react';
import { GatheringDetail } from '@/types/gathering';
import JoinedCountsProgressBar from '@/components/gatherings/list/JoinedCountsProgressBar';
import { Heart } from 'lucide-react';

interface Props {
  gathering: GatheringDetail;
}

export default function GatheringDetailPage({ gathering }: Props) {
  const {
    name,
    type,
    dateTime,
    registrationEnd,
    location,
    participantCount,
    capacity,
    image,
  } = gathering;

  // 날짜 · 시간 포맷 예시
  const date = new Date(dateTime).toLocaleDateString('ko-KR', { month: 'numeric', day: 'numeric' });
  const time = new Date(dateTime).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="container mx-auto px-4 lg:px-8 py-8 space-y-8">
      {/* 1. 이미지 + 마감 뱃지 */}
      <div className="relative">
        <img
          src={image}
          alt={name}
          className="w-full rounded-lg object-cover aspect-video shadow-md"
        />
        <span className="absolute top-4 right-4 px-2 py-1 bg-orange-600 text-xs text-white rounded-full">
          마감 {new Date(registrationEnd).toLocaleTimeString('ko-KR', { hour: 'numeric' })}시
        </span>
      </div>

      {/* 2. 상세 카드 */}
      <div className="relative p-6 bg-white rounded-xl shadow">
        <h1 className="text-2xl font-semibold">{name}</h1>
        <p className="mt-1 text-sm text-gray-600">{type}</p>

        <div className="flex items-center space-x-2 mt-4">
          <span className="px-2 py-1 bg-gray-100 text-sm rounded">{date}일</span>
          <span className="px-2 py-1 bg-gray-800 text-sm text-white rounded">{time}</span>
        </div>

        <button className="absolute top-6 right-6">
          <Heart className="w-6 h-6 text-gray-400 hover:text-red-500 transition-colors" />
        </button>

        {/* 3. 참가 현황 */}
        <div className="mt-6">
          <div className="flex justify-between text-sm text-gray-500 mb-1">
            <span>최소인원 5명</span>
            <span>최대인원 {capacity}명</span>
          </div>
          <JoinedCountsProgressBar
            participantCount={participantCount}
            capacity={capacity}
          />
        </div>
      </div>

      {/* 4. 리뷰 섹션 (우선 목업) */}
      <section>
        <h2 className="text-lg font-medium mb-4">이용자들은 이 프로그램을 이렇게 느꼈어요!</h2>
        {/* TODO: ReviewSection 컴포넌트로 교체 */}
        <p className="text-center text-gray-400">리뷰가 아직 없습니다.</p>
      </section>

      {/* 5. 참여하기 CTA */}
      <div className="sticky bottom-0 bg-white py-4">
        <div className="max-w-3xl mx-auto flex justify-end">
          <button className="bg-orange-600 hover:bg-orange-700 text-white rounded-lg py-2 px-6">
            참여하기
          </button>
        </div>
      </div>
    </div>
  );
}
